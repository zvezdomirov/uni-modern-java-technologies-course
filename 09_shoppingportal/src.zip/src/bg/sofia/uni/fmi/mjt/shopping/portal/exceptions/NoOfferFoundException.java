package bg.sofia.uni.fmi.mjt.shopping.portal.exceptions;

public class NoOfferFoundException extends Exception {
    public NoOfferFoundException(String message) {
        super(message);
    }
}
