package bg.sofia.uni.fmi.mjt.cache.enums;

public enum EvictionPolicy {
    RANDOM_REPLACEMENT,
    LEAST_FREQUENTLY_USED
}
