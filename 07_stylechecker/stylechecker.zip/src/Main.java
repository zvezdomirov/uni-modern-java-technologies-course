import bg.sofia.uni.fmi.mjt.stylechecker.StyleChecker;
import java.io.FileReader;
import java.io.FileWriter;

public class Main {
    public static void main(String[] args) {
        StyleChecker checker = new StyleChecker();
        try {
            checker.checkStyle(new FileReader("inputFile.txt"),
                    new FileWriter("outputFile.txt"));
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
