package bg.sofia.uni.fmi.mjt.authapp.exceptions;

public enum OpType {
    READ, WRITE, REGISTER, CLOSE
}
