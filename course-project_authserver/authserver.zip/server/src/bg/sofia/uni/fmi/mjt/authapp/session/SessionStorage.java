package bg.sofia.uni.fmi.mjt.authapp.session;

import bg.sofia.uni.fmi.mjt.authapp.users.User;
import java.io.IOException;
import java.nio.ByteBuffer;
import java.nio.channels.SocketChannel;
import java.util.Map;
import java.util.Timer;
import java.util.TimerTask;
import java.util.concurrent.ConcurrentHashMap;

public class SessionStorage {

    private static final String SESSION_TIMEOUT_MESSAGE =
            "Your session has timed out. You've been logged out.";
    private Map<Session, User> userBySession;
    private Map<User, Session> sessionByUser;
    private Map<String, Session> sessionsById;
    private Map<SocketChannel, User> userByChannel;
    private Map<User, SocketChannel> channelByUser;

    public SessionStorage() {
        userBySession = new ConcurrentHashMap<>();
        sessionByUser = new ConcurrentHashMap<>();
        sessionsById = new ConcurrentHashMap<>();
        userByChannel = new ConcurrentHashMap<>();
        channelByUser = new ConcurrentHashMap<>();
    }

    public Session newSession(User user, SocketChannel channel) {
        Session session = Session.createSession();
        addUserSession(user, session);
        login(session, channel);
        Timer killSessionTimer = new Timer();
        killSessionTimer.schedule(new TimerTask() {
            @Override
            public void run() {
                invalidateUserSession(user);
                try {
                    channel.write(ByteBuffer.wrap(
                            SESSION_TIMEOUT_MESSAGE.getBytes()));
                } catch (IOException e) {
                    e.printStackTrace();
                }
            }
        }, session.getSecondsToLive() * 1000);
        return session;
    }

    public boolean isUserLoggedIn(SocketChannel channel) {
        return userByChannel.containsKey(channel);
    }

    public void login(Session session, SocketChannel channel) {
        User user = userBySession.get(session);
        userByChannel.put(channel, user);
        channelByUser.put(user, channel);
    }

    private void addUserSession(User user, Session session) {
        userBySession.put(session, user);
        sessionByUser.put(user, session);
        sessionsById.put(session.getId(), session);
    }

    public void logout(SocketChannel channel) {
        User user = userByChannel.get(channel);
        userByChannel.remove(channel);
        channelByUser.remove(user);
    }

    public void invalidateUserSession(User user) {
        SocketChannel channel = channelByUser.get(user);
        Session session = sessionByUser.get(user);
        logout(channel);
        userBySession.remove(session);
        sessionByUser.remove(user);
        sessionsById.remove(session.getId());
    }

    public Session getById(String sessionId) {
        return sessionsById.get(sessionId);
    }

    public User getUserBySession(Session session) {
        if (session == null) {
            return null;
        }
        return userBySession.get(session);
    }

    public boolean hasValidSession(SocketChannel channel) {
        User channelUser = userByChannel.get(channel);
        return sessionByUser.containsKey(channelUser);
    }

    public User getUserByChannel(SocketChannel channel) {
        return userByChannel.get(channel);
    }

    public void updateUserInfo(SocketChannel channel, User newUser) {
        User oldUser = userByChannel.get(channel);
        Session userSession = sessionByUser.get(oldUser);
        userByChannel.put(channel, newUser);
        userBySession.put(userSession, newUser);
        channelByUser.remove(oldUser);
        channelByUser.put(newUser, channel);
        sessionByUser.remove(oldUser);
        sessionByUser.put(newUser, userSession);
    }
}
