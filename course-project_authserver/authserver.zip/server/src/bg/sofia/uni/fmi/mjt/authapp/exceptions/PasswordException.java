package bg.sofia.uni.fmi.mjt.authapp.exceptions;

public class PasswordException extends RuntimeException {
    public PasswordException(String message) {
        super(message);
    }
}
