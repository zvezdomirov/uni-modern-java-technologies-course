package bg.sofia.uni.fmi.mjt.authapp.users;

public enum Role {
    UNAUTHENTICATED,
    AUTHENTICATED,
    ADMIN
}
